USE MovieManagementSystem;

DROP TABLE IF EXISTS Genre;
CREATE TABLE Genre (
  genre_id INT PRIMARY KEY,
  name VARCHAR(50) UNIQUE NOT NULL
);

DROP TABLE IF EXISTS Director;
CREATE TABLE Director (
  director_id INT PRIMARY KEY,
  name VARCHAR(100) NOT NULL,
  birthdate DATE
);
DROP TABLE IF EXISTS Movie;
CREATE TABLE Movie (
  movie_id INT PRIMARY KEY,
  title VARCHAR(100) NOT NULL,
  release_year INT,
  duration INT,
  language VARCHAR(50),
  rating FLOAT CHECK (rating BETWEEN 0 AND 10),
  director_id INT,
  FOREIGN KEY (director_id) REFERENCES Director(director_id)
);

CREATE TABLE Actor (
  actor_id INT PRIMARY KEY,
  name VARCHAR(100),
  birthdate DATE
);

CREATE TABLE MovieGenre (
  movie_id INT,
  genre_id INT,
  PRIMARY KEY (movie_id, genre_id),
  FOREIGN KEY (movie_id) REFERENCES Movie(movie_id),
  FOREIGN KEY (genre_id) REFERENCES Genre(genre_id)
);

CREATE TABLE MovieCast (
  movie_id INT,
  actor_id INT,
  role VARCHAR(100),
  PRIMARY KEY (movie_id, actor_id),
  FOREIGN KEY (movie_id) REFERENCES Movie(movie_id),
  FOREIGN KEY (actor_id) REFERENCES Actor(actor_id)
);

CREATE TABLE SystemUser (
  user_id INT PRIMARY KEY,
  name VARCHAR(100),
  email VARCHAR(100),
  signup_date DATE
);

DROP TABLE IF EXISTS Review;
CREATE TABLE Review (
  review_id INT PRIMARY KEY,
  user_id INT,
  movie_id INT,
  rating FLOAT,
  comment TEXT,
  review_date DATE,
  FOREIGN KEY (user_id) REFERENCES SystemUser(user_id),
  FOREIGN KEY (movie_id) REFERENCES Movie(movie_id)
);

CREATE TABLE Screening (
  screening_id INT PRIMARY KEY,
  movie_id INT,
  screen_number INT,
  show_time DATETIME,
  location VARCHAR(100),
  FOREIGN KEY (movie_id) REFERENCES Movie(movie_id)
);

CREATE TABLE Ticket (
  ticket_id INT PRIMARY KEY,
  screening_id INT,
  user_id INT,
  seat_number VARCHAR(10),
  booking_time DATETIME,
  FOREIGN KEY (screening_id) REFERENCES Screening(screening_id),
  FOREIGN KEY (user_id) REFERENCES SystemUser(user_id)
);

INSERT INTO Genre(genre_id,name)
VALUES
(1, 'Action'),
(2, 'Drama'),
(3, 'Comedy'),
(4, 'Sci-Fi'),
(5, 'Animated'),
(6, 'Thriller');
INSERT INTO Genre(genre_id, name)
VALUES
(7, 'Romance'),
(8, 'Fantasy'),
(9, 'Horror'),
(10, 'Adventure'),
(11, 'Musical');


INSERT INTO Director(director_id,name,birthdate)
VALUES
(1, 'Christopher Nolan', '1970-07-30'),
(2, 'Rajkumar Hirani', '1962-11-20'),
(3, 'Sanjay Leela Bhansali', '1963-02-24'),
(4, 'Hayao Miyazaki', '1941-01-05'),
(5, 'James Cameron', '1954-08-16'),
(6, 'Director 6', '1965-01-07'),
(7, 'Director 7', '1965-01-08'),
(8, 'Director 8', '1965-01-09'),
(9, 'Director 9', '1965-01-10'),
(10, 'Director 10', '1965-01-11'),
(11, 'Director 11', '1965-01-12'),
(12, 'Director 12', '1965-01-13'),
(13, 'Director 13', '1965-01-14'),
(14, 'Director 14', '1965-01-15'),
(15, 'Director 15', '1965-01-16'),
(16, 'Director 16', '1965-01-17'),
(17, 'Director 17', '1965-01-18'),
(18, 'Director 18', '1965-01-19'),
(19, 'Director 19', '1965-01-20'),
(20, 'Director 20', '1965-01-21'),
(21, 'Director 21', '1965-01-22'),
(22, 'Director 22', '1965-01-23'),
(23, 'Director 23', '1965-01-24'),
(24, 'Director 24', '1965-01-25'),
(25, 'Director 25', '1965-01-26');


INSERT INTO Movie(movie_id,title,release_year,duration,language,rating,director_id)
VALUES
(101, 'Inception', 2010, 148, 'English', 8.8, 1),
(102, '3 Idiots', 2009, 170, 'Hindi', 8.4, 2),
(103, 'Bajirao Mastani', 2015, 158, 'Hindi', 7.2, 3),
(104, 'Spirited Away', 2001, 125, 'Japanese', 8.6, 4),
(105, 'Avatar', 2009, 162, 'English', 7.8, 5),
(106, 'PK', 2014, 153, 'Hindi', 8.1, 2),
(107, 'Interstellar', 2014, 169, 'English', 8.6, 1),
(108, 'The Lion King', 1994, 88, 'English', 8.5, 5),
(109, 'Dangal', 2016, 161, 'Hindi', 8.4, 2),
(110, 'The Dark Knight', 2008, 152, 'English', 9.0, 1),
(111, 'The Social Network', 2010, 120, 'English', 7.7, 6),
(112, 'Zindagi Na Milegi Dobara', 2011, 155, 'Hindi', 8.2, 7),
(113, 'Coco', 2017, 105, 'English', 8.4, 8),
(114, 'Gully Boy', 2019, 153, 'Hindi', 8.0, 7),
(115, 'Avengers: Endgame', 2019, 181, 'English', 8.4, 9),
(116, 'Parasite', 2019, 132, 'Korean', 8.6, 10),
(117, 'Tamasha', 2015, 139, 'Hindi', 7.3, 11),
(118, 'The Matrix', 1999, 136, 'English', 8.7, 12),
(119, 'Barfi!', 2012, 151, 'Hindi', 8.1, 13),
(120, 'Frozen', 2013, 102, 'English', 7.4, 14),
(121, 'Baahubali: The Beginning', 2015, 159, 'Telugu', 8.0, 15),
(122, 'Drishyam', 2015, 163, 'Hindi', 8.2, 16),
(123, 'Black Panther', 2018, 134, 'English', 7.3, 9),
(124, 'Queen', 2014, 146, 'Hindi', 8.1, 17),
(125, 'Toy Story 3', 2010, 103, 'English', 8.3, 8),
(126, 'Barbie', 2023, 114, 'English', 7.0, 18),
(127, 'Brahmastra', 2022, 167, 'Hindi', 6.7, 19),
(128, 'Mad Max: Fury Road', 2015, 120, 'English', 8.1, 20),
(129, 'Dear Zindagi', 2016, 150, 'Hindi', 7.5, 11),
(130, 'Ratatouille', 2007, 111, 'English', 8.1, 8);

INSERT INTO MovieGenre(movie_id,genre_id)
VALUES
(101, 1),
(101, 4),
(102, 2),
(102, 3),
(103, 2),
(103, 6),
(104, 5),
(105, 4),
(105, 1),
(106, 3),
(107, 4),
(107, 1),
(108, 5),
(109, 2),
(109, 1),
(110, 1), 
(110, 6),
(111, 2),   
(112, 2),   
(112, 3),   
(113, 5),   
(114, 2),   
(114, 3),   
(115, 1),   
(115, 10),  
(116, 2),   
(116, 6),   
(117, 2),   
(117, 7),   
(118, 1),   
(118, 4),   
(119, 2),   
(119, 3),   
(120, 5),  
(120, 8),   
(121, 1),   
(121, 10);  


INSERT INTO Actor(actor_id,name,birthdate)
VALUES
(1, 'Aamir Khan', '1965-03-14'),
(2, 'Leonardo DiCaprio', '1974-11-11'),
(3, 'Deepika Padukone', '1986-01-05'),
(4, 'Matthew McConaughey', '1969-11-04'),
(5, 'Scarlett Johansson', '1984-11-22'),
(6, 'Ranveer Singh', '1985-07-06'),
(7, 'Emma Watson', '1990-04-15'),
(8, 'Chris Evans', '1981-06-13'),
(9, 'Kriti Sanon', '1990-07-27'),
(10, 'Ryan Reynolds', '1976-10-23'),
(11, 'Anushka Sharma', '1988-05-01'),
(12, 'Will Smith', '1968-09-25'),
(13, 'Ayushmann Khurrana', '1984-09-14'),
(14, 'Natalie Portman', '1981-06-09'),
(15, 'Varun Dhawan', '1987-04-24'),
(16, 'Jennifer Lawrence', '1990-08-15'),
(17, 'Hrithik Roshan', '1974-01-10'),
(18, 'Anne Hathaway', '1982-11-12'),
(19, 'Kartik Aaryan', '1990-11-22'),
(20, 'Emma Stone', '1988-11-06'),
(21, 'Sidharth Malhotra', '1985-01-16'),
(22, 'Tom Holland', '1996-06-01'),
(23, 'Vicky Kaushal', '1988-05-16'),
(24, 'Zendaya', '1996-09-01'),
(25, 'John Abraham', '1972-12-17');


INSERT INTO MovieCast(movie_id,actor_id,role)
VALUES
(101, 2, 'Cobb'),
(102, 1, 'Rancho'),
(103, 3, 'Mastani'),
(104, 4, 'Voice Actor'),
(105, 5, 'Neytiri'),
(106, 1, 'PK'),
(107, 4, 'Cooper'),
(108, 5, 'Simba (voice)'),
(109, 1, 'Mahavir Singh Phogat'),
(110, 2, 'Bruce Wayne'),
(111, 6, 'Hero'),
(112, 7, 'Lead Female'),
(113, 8, 'Agent'),
(114, 9, 'Supporting Role'),
(115, 10, 'Protagonist'),
(116, 11, 'Journalist'),
(117, 12, 'Police Officer'),
(118, 13, 'Comedian'),
(119, 14, 'Queen'),
(120, 15, 'Student'),
(121, 16, 'Scientist'),
(122, 17, 'Detective'),
(123, 18, 'Lawyer'),
(124, 19, 'Rebel'),
(125, 20, 'Explorer'),
(126, 21, 'Soldier'),
(127, 22, 'Tech Genius'),
(128, 23, 'Spy'),
(129, 24, 'Princess'),
(130, 25, 'Bodyguard');


INSERT INTO SystemUser(user_id,name,email,signup_date) 
VALUES
(1, 'Ali Raza', 'ali@example.com', '2024-01-15'),
(2, 'Fatima Khan', 'fatima@example.com', '2024-02-10'),
(3, 'John Doe', 'john@example.com', '2024-03-01'),
(4, 'Sara Lee', 'sara@example.com', '2024-03-20'),
(5, 'Bilal Ahmed', 'bilal@example.com', '2024-04-05'),
(11, 'Zoya Malik', 'zoya.malik@example.com', '2024-03-01'),
(12, 'Adeel Qureshi', 'adeel.qureshi@example.com', '2024-03-02'),
(13, 'Mehak Iqbal', 'mehak.iqbal@example.com', '2024-03-03'),
(14, 'Hassan Raza', 'hassan.raza@example.com', '2024-03-04'),
(15, 'Iqra Tariq', 'iqra.tariq@example.com', '2024-03-05'),
(16, 'Taha Ahmed', 'taha.ahmed@example.com', '2024-03-06'),
(17, 'Sana Fatima', 'sana.fatima@example.com', '2024-03-07'),
(18, 'Osama Shah', 'osama.shah@example.com', '2024-03-08'),
(19, 'Laiba Sheikh', 'laiba.sheikh@example.com', '2024-03-09'),
(20, 'Umair Khan', 'umair.khan@example.com', '2024-03-10'),
(21, 'Noor Zahra', 'noor.zahra@example.com', '2024-03-11'),
(22, 'Yasir Mehmood', 'yasir.mehmood@example.com', '2024-03-12'),
(23, 'Hiba Anwar', 'hiba.anwar@example.com', '2024-03-13'),
(24, 'Zainab Rehman', 'zainab.rehman@example.com', '2024-03-14'),
(25, 'Ahsan Javed', 'ahsan.javed@example.com', '2024-03-15'),
(26, 'Anaya Saeed', 'anaya.saeed@example.com', '2024-03-16'),
(27, 'Nashit Ali', 'nashit.ali@example.com', '2024-03-17'),
(28, 'Mahnoor Riaz', 'mahnoor.riaz@example.com', '2024-03-18'),
(29, 'Fahad Mirza', 'fahad.mirza@example.com', '2024-03-19'),
(30, 'Huma Waqar', 'huma.waqar@example.com', '2024-03-20');

INSERT INTO SystemUser(user_id,name,email,signup_date) 
VALUES
(6, 'Reema Noor', 'reema@example.com', '2024-04-10'),
(7, 'Hamza Shahid', 'hamza@example.com', '2024-04-12');


INSERT INTO Review(review_id,user_id,movie_id,rating,comment,review_date)
VALUES
(1, 1, 101, 9, 'Mind-blowing concept.', '2024-04-10'),
(2, 2, 102, 8, 'Emotional and funny.', '2024-04-12'),
(3, 3, 103, 7, 'Epic love story.', '2024-04-15'),
(4, 4, 104, 9, 'Visually stunning.', '2024-04-18'),
(5, 5, 105, 8, 'Great effects.', '2024-04-20');
INSERT INTO Review(review_id,user_id,movie_id,rating,comment,review_date)
VALUES
(6, 6, 111, 7.0, 'Entertaining watch!', '2024-05-01'),
(7, 7, 112, 6.5, 'Good effects.', '2024-05-02'),
(11, 11, 114, 8.0, 'Brilliant performance.', '2024-05-04'),
(12, 12, 115, 6.0, 'Could be better.', '2024-05-05'),
(13, 13, 116, 7.8, 'Strong message.', '2024-05-06'),
(14, 14, 117, 8.2, 'Excellent cinematography.', '2024-05-07'),
(15, 15, 118, 7.4, 'Solid movie.', '2024-05-08'),
(16, 16, 119, 6.9, 'Bit slow-paced.', '2024-05-09'),
(17, 17, 120, 7.7, 'Family-friendly.', '2024-05-10'),
(18, 18, 121, 8.1, 'Touching story.', '2024-05-11'),
(19, 19, 122, 6.6, 'Average.', '2024-05-12'),
(20, 20, 123, 7.3, 'Funny moments.', '2024-05-13'),
(21, 21, 124, 7.9, 'Visually great.', '2024-05-14'),
(22, 22, 125, 8.0, 'Highly recommended.', '2024-05-15'),
(23, 23, 126, 6.2, 'Could improve.', '2024-05-16'),
(24, 24, 127, 7.6, 'Nice editing.', '2024-05-17'),
(25, 25, 128, 8.3, 'Superb plot.', '2024-05-18'),
(26, 26, 129, 7.2, 'Loved the vibe.', '2024-05-19'),
(27, 27, 130, 6.8, 'Not bad.', '2024-05-20');

INSERT INTO Screening(screening_id,movie_id,screen_number,show_time,location)
VALUES
(1, 101, 1, '2024-06-15 18:00:00', 'Lahore'),
(2, 102, 2, '2024-06-16 20:00:00', 'Karachi'),
(3, 103, 1, '2024-06-17 17:00:00', 'Islamabad'),
(4, 104, 2, '2024-06-18 19:00:00', 'Lahore'),
(5, 105, 3, '2024-06-19 21:00:00', 'Karachi'),
(8, 111, 1, '2024-06-22 18:00:00', 'Lahore'),
(9, 112, 2, '2024-06-23 19:00:00', 'Karachi'),
(10, 113, 3, '2024-06-24 17:30:00', 'Islamabad'),
(11, 114, 1, '2024-06-25 20:00:00', 'Multan'),
(12, 115, 2, '2024-06-26 18:45:00', 'Rawalpindi'),
(13, 116, 3, '2024-06-27 21:00:00', 'Lahore'),
(14, 117, 1, '2024-06-28 18:00:00', 'Karachi'),
(15, 118, 2, '2024-06-29 19:00:00', 'Islamabad'),
(16, 119, 3, '2024-06-30 20:00:00', 'Multan'),
(17, 120, 1, '2024-07-01 18:00:00', 'Rawalpindi'),
(18, 121, 2, '2024-07-02 19:00:00', 'Lahore'),
(19, 122, 3, '2024-07-03 17:30:00', 'Karachi'),
(20, 123, 1, '2024-07-04 20:00:00', 'Islamabad'),
(21, 124, 2, '2024-07-05 18:45:00', 'Multan'),
(22, 125, 3, '2024-07-06 21:00:00', 'Rawalpindi'),
(23, 126, 1, '2024-07-07 18:00:00', 'Lahore'),
(24, 127, 2, '2024-07-08 19:00:00', 'Karachi'),
(25, 128, 3, '2024-07-09 20:00:00', 'Islamabad'),
(26, 129, 1, '2024-07-10 18:00:00', 'Multan'),
(27, 130, 2, '2024-07-11 19:00:00', 'Rawalpindi');


INSERT INTO Ticket(ticket_id,screening_id,user_id,seat_number,booking_time)
VALUES
(1, 1, 1, 'A1', '2024-06-10 10:00:00'),
(2, 1, 2, 'A2', '2024-06-10 10:05:00'),
(3, 2, 3, 'B1', '2024-06-11 11:00:00'),
(4, 3, 4, 'C1', '2024-06-12 12:00:00'),
(5, 4, 5, 'D1', '2024-06-13 13:00:00'),
(8, 8, 1, 'C2', '2024-06-20 10:00:00'),
(9, 9, 2, 'C3', '2024-06-21 11:00:00'),
(10, 10, 3, 'C4', '2024-06-22 12:00:00'),
(11, 11, 11, 'C5', '2024-06-23 13:00:00'),
(12, 12, 12, 'C6', '2024-06-24 14:00:00'),
(13, 13, 13, 'C7', '2024-06-25 15:00:00'),
(14, 14, 14, 'C8', '2024-06-26 16:00:00'),
(15, 15, 15, 'C9', '2024-06-27 17:00:00'),
(16, 16, 16, 'D1', '2024-06-28 18:00:00'),
(17, 17, 17, 'D2', '2024-06-29 19:00:00'),
(18, 18, 18, 'D3', '2024-06-30 20:00:00'),
(19, 19, 19, 'D4', '2024-07-01 21:00:00'),
(20, 20, 20, 'D5', '2024-07-02 22:00:00'),
(21, 21, 21, 'D6', '2024-07-03 23:00:00'),
(22, 22, 22, 'D7', '2024-07-04 10:00:00'),
(23, 23, 23, 'D8', '2024-07-05 11:00:00'),
(24, 24, 24, 'D9', '2024-07-06 12:00:00'),
(25, 25, 25, 'E1', '2024-07-07 13:00:00'),
(26, 26, 26, 'E2', '2024-07-08 14:00:00'),
(27, 27, 27, 'E3', '2024-07-09 15:00:00');


INSERT INTO Screening(screening_id,movie_id,screen_number,show_time,location)
VALUES
(6, 106, 1, '2024-06-20 16:00:00', 'Islamabad'),
(7, 107, 2, '2024-06-21 18:00:00', 'Lahore');

INSERT INTO Ticket(ticket_id,screening_id,user_id,seat_number,booking_time)
VALUES
(6, 5, 1, 'E1', '2024-06-14 14:00:00'),
(7, 6, 2, 'F1', '2024-06-15 15:00:00');

-- 1. Users who haven�t written reviews
SELECT name 
FROM SystemUser
WHERE user_id 
NOT IN (SELECT user_id FROM Review
);

-- 2. Count tickets per screening
SELECT screening_id, COUNT(*) AS total_tickets
FROM Ticket
GROUP BY screening_id;

-- 3. Top 5 highest-rated movies
SELECT TOP 5 M.title, AVG(R.rating) AS average_rating
FROM Movie M
JOIN Review R 
ON M.movie_id = R.movie_id
GROUP BY M.movie_id, M.title
ORDER BY average_rating DESC;


-- 4. List all actors in a specific movie
SELECT A.name, C.role
FROM Actor A
JOIN MovieCast C 
ON A.actor_id = C.actor_id
WHERE C.movie_id = 101;

-- 5. Screenings at a given location
SELECT title, show_time
FROM Movie 
JOIN Screening 
ON Movie.movie_id = Screening.movie_id
WHERE location = 'Lahore';

-- 6. Movies in a specific genre
SELECT M.title
FROM Movie M
JOIN MovieGenre MG
ON M.movie_id = MG.movie_id
JOIN Genre G 
ON MG.genre_id = G.genre_id
WHERE G.name = 'Drama';

-- 7. Directors and movie count
SELECT D.name, COUNT(*) AS movie_count
FROM Director D 
JOIN Movie M 
ON D.director_id = M.director_id
GROUP BY D.director_id,D.name;

-- 8. Bookings by specific user
SELECT T.ticket_id, M.title, S.show_time
FROM Ticket T
JOIN Screening S
ON T.screening_id = S.screening_id
JOIN Movie M
ON S.movie_id = M.movie_id
WHERE T.user_id = 1;

-- 9. Reviews with high rating
SELECT U.name, M.title, R.rating
FROM Review R
JOIN SystemUser U 
ON R.user_id = U.user_id
JOIN Movie M 
ON R.movie_id = M.movie_id
WHERE R.rating > 8;

 --10.Total number of movies
SELECT COUNT(*) AS total_movies
FROM Movie;

-- DCL commands
           --administrator--
		   --1. create login 
CREATE LOGIN [bilal_ahmed] 
WITH PASSWORD = 'Bilal@2024';

-- 2. Create database user 
USE MovieManagementSystem; 
CREATE USER [bilal_ahmed] FOR LOGIN [bilal_ahmed];

-- 3. Grant permissions 
GRANT SELECT, INSERT, UPDATE, DELETE ON Movie TO [bilal_ahmed];
GRANT SELECT, INSERT, UPDATE, DELETE ON Review TO [bilal_ahmed];
GRANT SELECT, INSERT, UPDATE, DELETE ON Ticket TO [bilal_ahmed];
GRANT SELECT, INSERT, UPDATE, DELETE ON Genre TO [bilal_ahmed];
GRANT SELECT, INSERT, UPDATE, DELETE ON Director TO [bilal_ahmed];
GRANT SELECT, INSERT, UPDATE, DELETE ON SystemUser TO [bilal_ahmed];

        ---reviewer---
CREATE LOGIN fatima_khan
WITH PASSWORD = 'Fatima@2024';

USE MovieManagementSystem;
CREATE USER fatima_khan FOR LOGIN fatima_khan;

GRANT SELECT ON Movie TO fatima_khan;
GRANT SELECT, INSERT ON Review TO fatima_khan;

      ---genre manager---
CREATE LOGIN mehak_iqbal 
WITH PASSWORD = 'Mehak@2024';

USE MovieManagementSystem;
CREATE USER mehak_iqbal FOR LOGIN mehak_iqbal;

GRANT SELECT, INSERT, UPDATE, DELETE ON Genre TO mehak_iqbal;

      ---ticket clerk---
CREATE LOGIN adeel_qureshi
WITH PASSWORD = 'Adeel@2024';

USE MovieManagementSystem;
CREATE USER adeel_qureshi FOR LOGIN adeel_qureshi;

GRANT SELECT, INSERT, UPDATE ON Ticket TO adeel_qureshi;
GRANT SELECT ON Screening TO adeel_qureshi;


SELECT * FROM Movie; 

SELECT * FROM Review;

INSERT INTO Review(review_id, user_id, movie_id, rating, comment, review_date)
VALUES (31, 2, 101, 8, 'Great movie', '2024-07-01'); 

DELETE FROM Review WHERE review_id = 31; 

 --revoke--
REVOKE INSERT ON Review 
FROM fatima_khan;













